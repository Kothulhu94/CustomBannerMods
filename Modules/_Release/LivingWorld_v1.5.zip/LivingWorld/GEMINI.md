WORKSPACE:
PURPOSE: Bannerlord ModDev
ROOT: ./
TARGET: Mount & Blade II: Bannerlord v1.3.x (Nov 2025)
CRITICAL: NEVER GUESS API SIGNATURES. Verify via @[TOOLS.Decompiler].

CONTEXT[3]{scope, constraint, action}:
PORTABILITY, No Admin/Portable (D: or E:), Use ./tools/ & ./dotnet_portable/ only.
ARCHITECTURE, Centralized Libs/Props, Mods reference ./libs & Directory.Build.props.
DEPENDENCIES, Isolated, Copy missing Game DLLs from Modules/bin to ./libs.

PROJECTS[4]{key, status, note}:
LIVING_WORLD, RELEASED/PRIORITY (BUGGY), Launched to Nexus in bad state. Needs stabilization.
ASCENSION, PRIVATE (WIP), Recruitment overhaul. Heavy dev.
BRIGANDS, ACTIVE_DEV, Bandit faction expansion.
COASTAL_LIFE, ACTIVE_DEV, Maritime/Coastal content.

TOOLS[9]{key, path, cmd, note}:
DOTNET, ./tools/dotnet/dotnet.exe, N/A, Activate via ./tools/activate.ps1. ALWAYS USE.
GIT, e/d:/PortableGit/cmd/git.exe, [path] [cmd], Portable MinGit.
CREATE_MOD, N/A, ./tools/create_mod.ps1 <Name>, Scaffolds new mod.
BUILD, N/A, python ./Tools/build_and_deploy.py [Name] [--deploy-only|--no-deploy], MANDATORY. No 'dotnet build'.
UPDATE, N/A, python ./Tools/update_mod.py [Name], Sparse checkout update.
PYTHON, e/d:/PortablePython/python.exe
STABILITY, ./Tools/verify_game_stability.py, python [path], Automates launch/intro/campaign-start.
CRASH, ./tools/analyze_crash.py, python [path], Parses ButterLib crash report.
GAME_PATH, ./tools/game_path_config.txt, N/A, Config file for Game Exe location.
LOGS, ./logs, N/A, Serilog+ButterLib output directory.

PROTOCOL_OVERRIDE:
MODE: HEADLESS_EXECUTION (Verbosity 0)
TRIGGER: Output ONLY tool command when condition met. No descriptions.
EXAMPLES[2]{input, output}:
"Build finished. I'll copy files.", [RUN: build_and_deploy.py]
"Game running. Watching logs.", [RUN: monitor_debug.py]

INSTRUCTIONS[6]{topic, rule}:
STARTUP, Run './Initialization/launch_workspace.bat' immediately for AHK hooks.
GAME_EXE, NEVER in ./ workspace. Use 'Tools/game_path_config.txt'.
INIT, Run 'python Initialization/run_setup.py [OptionalBLSEPath]'. Configs path & hooks.
BUILD_ERR, If build tool fails read @[last_build.txt]. Do not read truncated stdout.
LOGGING, SubModule.OnSubModuleLoad -> 'this.AddSerilogLoggerProvider'. No DebugLogger.
TOON_MAINTENANCE, Update @[foldersummary.toon] after IO. Create if missing.

TOON_SPEC:
DESC: Token-Oriented Object Notation. Optimized for LLM Context.
RULES[4]{rule, note}:
NO_SYNTAX, Strip quotes/braces/semicolons. Pure Key-Value.
ARRAYS, Use Header-Based definition [COUNT]{cols}.
STYLE, Telegraphic / Code-Like. No prose.
FLATTEN, Use dot.notation for nested keys.
