# LivingWorld

**Experience a deeper, more alive Calradia.**

**LivingWorld** is a comprehensive overhaul that breathes new life into the campaign map, integrating economy, labor, politics, and clan progression into a single substantial expansion. It transforms the journey from a lonely wanderer to a powerful ruler, offering new ways to interact with settlements, villages, and your own kingdom.

Designed for stability and compatibility, LivingWorld merges the functionality of several classic mods into a unified codebase with a centralized Mod Configuration Menu (MCM), allowing you to enable, disable, or tweak every feature to your liking.

---

## 🌟 Key Features

### 🏘️ Landlord: Real Estate & Economy
Become a master of coin without needing to be a master of war.
- **Purchase Land:** Buy plots of land in towns and villages.
- **Passive Income:** Establish a steady revenue stream that grows over time.
- **Investment:** Upgrade your properties to increase hearth growth and prosperity in the attached settlement.
- **Banking:** Store gold in secure accounts to protect your wealth from defeat.

### 🚜 Honest Work: The Commoner's Life
Roleplay the humble beginnings of your hero.
- **Village Jobs:** Don't just raid villages—work in them. Take up jobs like harvesting, mining, or guarding.
- **Wages & Rewards:** Earn daily wages and receive bonus resource rewards for hard work.
- **Skill Progression:** Gain relevant skill XP (Athletics, trade, etc.) while working, providing a safe way to train early game.
- **Troop XP:** Your soldiers can work alongside you, gaining experience without the risk of battle.

### 📜 Better Governance: Politics & Kingdom Management
Rule your realm with unprecedented control.
- **New Policies:** Enact a suite of new kingdom policies that meaningfully impact loyalty, security, and tax efficiency.
- **Crisis Management:** Tools to handle starving garrisons or low-loyalty towns.
- **Stabilization:** Policies specifically designed to help the AI (and player) hold onto conquered territories for longer.

### ⚔️ Living Legend: Renown & Evolution
Your legend should be defined by your deeds, not arbitrary caps.
- **Dynamic Limits:** Companion limits and party sizes scale dynamically with your Renown and Leadership.
- **Clan Progression:** Adjusted requirements for Clan Tiers to smooth out the progression curve.
- **Legacy:** Features that allow your clan's influence to persist and grow in unique ways.

### 🛡️ New Clans & Companions
- **Companion Vasalage:** Elevate your trusted companions to nobility, allowing them to form their own clans and hold fiefs under your banner.
- **Minor Faction Interaction:** Enhanced interactions with minor clans to make them feel like a living part of the world.

---

## ⚙️ Fully Configurable (MCM)
LivingWorld is built on the philosophy of player choice.
- **Modular Design:** Want the Economy features but not the Kingdom policies? You can toggle entire modules on or off in the main menu.
- **Granular Balance:** Adjust job wages, plot prices, renown costs, and policy effects primarily through the Mod Configuration Menu.

## 📥 Installation
1. Requires **Harmony**, **ButterLib**, **UIExtenderEx**, and **MCM v5**.
2. Install **LivingWorld** into your game's `Modules` folder.
3. Enable `LivingWorld` in the Bannerlord Launcher.
4. **Load Order:** Load after the requirement mods and Native modules.

## ⚠️ Compatibility
- **Save Game Compatible:** Can be added to an existing save.
- **Removal:** Removing mid-save is generally **not** recommended if you own plots or have active policies from the mod. 
