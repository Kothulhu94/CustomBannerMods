# LivingWorld v1.6

## Changelog

### New Features

#### Siege Protocols (HonestWork)
- **Player Interaction**: When a siege begins, players working in the settlement are interrupted and given choices to "Join the Defense" or "Leave the City". 
- **AI Behavior**: AI heroes now intelligently react to sieges, stopping work and joining the defense if appropriate.

#### Map Tooltips (Landlord)
- **Income Visibility**: Added a new tooltip to the main map info bar that displays total daily income from owned plots.
- **Detailed Breakdown**: Holding ALT while hovering shows a detailed breakdown of income per plot and settlement.

#### HappyParty Toggle
- **MCM Option**: Added a new "Enable Wanderer Dialogue" toggle in the Mod Configuration Menu.
- **Control**: Players can now disable the "Don't you have somewhere to be?" dialogue option for wanderers.

### Bug Fixes
- **FieldSquire**: Fixed a critical issue where the Settlement VM would fail to open after certain dialogue interactions.
